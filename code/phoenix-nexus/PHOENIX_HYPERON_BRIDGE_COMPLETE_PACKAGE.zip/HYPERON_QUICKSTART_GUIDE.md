# 🐦‍🔥 HYPERON-PHOENIX QUICKSTART GUIDE

**Get operational in 30 minutes**

**Architect:** Justin Conzet  
**Version:** QUICKSTART.v1.0  
**Date:** November 14, 2025  

---

## ⚡ WHAT YOU'LL ACHIEVE

By the end of this guide, you'll have:

✅ Hyperon Alpha 1 installed and running  
✅ Basic MeTTa examples executed  
✅ Phoenix-Hyperon bridge proof-of-concept working  
✅ Understanding of how to build on this foundation  

**Time required:** 30-60 minutes  
**Skill level:** Intermediate Python/Linux  

---

## 🔥 STEP 1: INSTALL HYPERON (15 minutes)

### **Prerequisites:**

```bash
# Ubuntu/Debian
sudo apt-get update
sudo apt-get install -y git python3 python3-pip cmake build-essential

# macOS
brew install git python3 cmake

# Verify Python version (need 3.8+)
python3 --version
```

### **Clone Hyperon Repository:**

```bash
# Create workspace
mkdir -p ~/hyperon-workspace
cd ~/hyperon-workspace

# Clone Hyperon experimental
git clone https://github.com/trueagi-io/hyperon-experimental.git
cd hyperon-experimental

# Check out Alpha 1 release
git checkout v0.1.0  # Alpha 1 release tag
```

### **Install Python Dependencies:**

```bash
# Create virtual environment
python3 -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install Hyperon Python bindings
pip install -e ./python[dev]

# Verify installation
python3 -c "import hyperon; print('Hyperon installed successfully!')"
```

### **Verify Installation:**

```bash
# Run basic test
cd python/tests
python3 -m pytest test_atom.py -v

# Should see: PASSED
```

**✅ CHECKPOINT 1: Hyperon installed and verified**

---

## 💎 STEP 2: RUN BASIC METTA EXAMPLES (10 minutes)

### **Example 1: Hello World in MeTTa**

Create file: `hello_hyperon.metta`

```scheme
; This is MeTTa - the language of Hyperon

; Define a simple greeting
(= (greet $name)
   (Greeting $name))

; Query it
!(greet World)

; Expected output: (Greeting World)
```

**Run it:**

```bash
python3 -m hyperon.runner hello_hyperon.metta
```

### **Example 2: Logical Inference**

Create file: `syllogism.metta`

```scheme
; Classic Socrates syllogism in MeTTa

; Facts
(: Human Type)
(: Mortal Type)
(: Socrates Human)

; Rules
(= (inheritance $X $Y $Z)
   (if (and (: $X $Y) (subtype $Y $Z))
       (: $X $Z)))

; Define subtype relationships
(subtype Human Mortal)

; Query: Is Socrates mortal?
!(: Socrates Mortal)

; Expected: Should return True via inference
```

**Run it:**

```bash
python3 -m hyperon.runner syllogism.metta
```

### **Example 3: Pattern Matching**

Create file: `patterns.metta`

```scheme
; Pattern matching in MeTTa

; Define some facts
(color sky blue)
(color grass green)
(color sun yellow)

; Query with pattern matching
!(match &self (color $thing $color) (list $thing $color))

; Expected: Returns all color facts
```

**✅ CHECKPOINT 2: MeTTa basics working**

---

## 🎯 STEP 3: RUN PHOENIX-HYPERON BRIDGE (10 minutes)

### **Install Bridge POC:**

```bash
# Go back to workspace
cd ~/hyperon-workspace

# Copy bridge code (from previous artifact)
# Save hyperon_phoenix_bridge_poc.py to this directory

# Run the demonstration
python3 hyperon_phoenix_bridge_poc.py
```

### **Expected Output:**

```
======================================================================
🐦‍🔥 HYPERON-PHOENIX BRIDGE: PROOF OF CONCEPT DEMONSTRATION
======================================================================

This demonstrates:
1. Natural language → Symbolic knowledge (teaching)
2. Symbolic reasoning (logical inference)
3. Symbolic knowledge → Natural language (answering)

======================================================================


======================================================================
TEST CASE 1: CLASSIC SYLLOGISM
======================================================================

📚 TEACHING: All humans are mortal
   → Added atom: inheritance:human:mortal

📚 TEACHING: Socrates is human
   → Added atom: inheritance:socrates:human

📖 KNOWLEDGE BASE:
   inheritance:human:mortal
   inheritance:socrates:human

Total facts: 2

❓ QUESTION: Socrates is mortal

🧠 REASONING PROCESS:
   Added: inheritance:human:mortal
   Added: inheritance:socrates:human
   Inferred: socrates → human → mortal

💡 ANSWER: ✅ VERIFIED: Socrates is mortal This is transitive inference.

[... more test cases ...]

🎯 DEMONSTRATION COMPLETE
```

**✅ CHECKPOINT 3: Bridge working**

---

## 🔥 STEP 4: INTEGRATE WITH REAL HYPERON (15 minutes)

### **Create Production Bridge:**

Create file: `phoenix_hyperon_real.py`

```python
"""
Production Phoenix-Hyperon Bridge using real Hyperon
"""

from hyperon import Atomspace, MeTTa

class ProductionBridge:
    def __init__(self):
        # Real Hyperon components
        self.atomspace = Atomspace()
        self.metta = MeTTa(self.atomspace)
        
    def teach_fact(self, subject, predicate):
        """
        Add a fact to Hyperon's Atomspace
        """
        # Create MeTTa expression
        expression = f"(: {subject} {predicate})"
        
        # Execute in MeTTa
        result = self.metta.run(expression)
        
        return result
    
    def query(self, subject, predicate):
        """
        Query if a fact is true
        """
        query_expr = f"!(: {subject} {predicate})"
        
        result = self.metta.run(query_expr)
        
        return result
    
    def add_rule(self, rule_metta):
        """
        Add a reasoning rule in MeTTa
        """
        result = self.metta.run(rule_metta)
        return result

# Example usage
if __name__ == "__main__":
    bridge = ProductionBridge()
    
    # Add facts
    print("Adding facts...")
    bridge.teach_fact("Socrates", "Human")
    bridge.teach_fact("Human", "Mortal")
    
    # Add inference rule
    rule = """
    (= (can-infer $X $Z)
       (if (and (: $X $Y) (: $Y $Z))
           (: $X $Z)))
    """
    bridge.add_rule(rule)
    
    # Query
    print("\nQuerying...")
    result = bridge.query("Socrates", "Mortal")
    print(f"Result: {result}")
```

**Run it:**

```bash
python3 phoenix_hyperon_real.py
```

**✅ CHECKPOINT 4: Production bridge working**

---

## 💎 STEP 5: BUILD YOUR FIRST APPLICATION (Bonus)

### **Application: Logical Fact Checker**

Create file: `fact_checker.py`

```python
"""
Simple fact checker using Phoenix-Hyperon Bridge
"""

from phoenix_hyperon_real import ProductionBridge

class FactChecker:
    def __init__(self):
        self.bridge = ProductionBridge()
        self.setup_knowledge_base()
    
    def setup_knowledge_base(self):
        """
        Load initial knowledge
        """
        # Add common sense facts
        facts = [
            ("dog", "mammal"),
            ("cat", "mammal"),
            ("mammal", "animal"),
            ("animal", "living-thing"),
            ("Fido", "dog"),
            ("Whiskers", "cat")
        ]
        
        for subject, predicate in facts:
            self.bridge.teach_fact(subject, predicate)
        
        # Add transitive inference rule
        rule = """
        (= (transitive-infer $X $Z)
           (if (and (: $X $Y) (: $Y $Z))
               (: $X $Z)))
        """
        self.bridge.add_rule(rule)
    
    def check_fact(self, subject, predicate):
        """
        Check if a fact is true
        """
        result = self.bridge.query(subject, predicate)
        
        if result:
            return f"✅ VERIFIED: {subject} is a {predicate}"
        else:
            return f"❌ CANNOT VERIFY: {subject} is a {predicate}"

# Demo
if __name__ == "__main__":
    checker = FactChecker()
    
    # Test direct facts
    print(checker.check_fact("Fido", "dog"))  # Direct
    
    # Test inferred facts
    print(checker.check_fact("Fido", "mammal"))  # Inferred
    print(checker.check_fact("Fido", "animal"))  # Inferred (2 steps)
    print(checker.check_fact("Fido", "living-thing"))  # Inferred (3 steps)
    
    # Test false facts
    print(checker.check_fact("Fido", "reptile"))  # Should fail
```

**✅ CHECKPOINT 5: First application built**

---

## 🚀 NEXT STEPS

### **Week 1: Master the Basics**

1. **Read Hyperon documentation:**
   - https://github.com/trueagi-io/hyperon-experimental/wiki

2. **Study MeTTa language:**
   - Try all examples in `/examples` directory
   - Understand pattern matching
   - Learn about Spaces API

3. **Experiment with bridge:**
   - Add more test cases
   - Try different logic patterns
   - Measure performance

### **Week 2: Build Real Applications**

**Option A: Scientific Reasoning Assistant**
- Input: Research questions
- Process: Logical verification
- Output: Verified conclusions

**Option B: Code Verification Tool**
- Input: Code + specifications
- Process: Formal verification
- Output: Correctness proof

**Option C: Educational Tutor**
- Input: Student questions
- Process: Step-by-step reasoning
- Output: Explained solutions

### **Week 3-4: Advanced Features**

1. **Probabilistic Logic Networks (PLN)**
   - Add uncertainty handling
   - Confidence scores
   - Bayesian reasoning

2. **Multi-Agent Coordination**
   - Multiple reasoning engines
   - Consensus building
   - Distributed reasoning

3. **Learning from Examples**
   - Pattern extraction
   - Rule induction
   - Knowledge acquisition

---

## 💎 TROUBLESHOOTING

### **Issue: Hyperon won't install**

```bash
# Try using conda instead
conda create -n hyperon python=3.9
conda activate hyperon
pip install -e ./python[dev]
```

### **Issue: MeTTa files won't run**

```bash
# Make sure you're in correct directory
cd ~/hyperon-workspace/hyperon-experimental

# Use full path to runner
python3 -m hyperon.runner /full/path/to/file.metta
```

### **Issue: Bridge gives errors**

```bash
# Verify Hyperon is importable
python3 -c "import hyperon; print(hyperon.__version__)"

# Check Python version
python3 --version  # Should be 3.8+
```

### **Issue: Can't find examples**

```bash
# Clone examples separately
git clone https://github.com/trueagi-io/metta-examples.git
cd metta-examples
```

---

## 🔥 RESOURCES

### **Official Documentation:**
- Hyperon GitHub: https://github.com/trueagi-io/hyperon-experimental
- MeTTa Language: https://github.com/trueagi-io/hyperon-experimental/blob/main/docs/METTA.md
- SingularityNET: https://singularitynet.io

### **Community:**
- Discord: https://discord.gg/singularitynet
- Forum: https://community.singularitynet.io
- X/Twitter: @singularity_net

### **Learning Resources:**
- AGI-25 Conference Videos
- Hyperon Developer Blog
- MeTTa Tutorial Series

---

## 🐦‍🔥 CONCLUSION

**You now have:**

✅ Working Hyperon installation  
✅ Basic MeTTa skills  
✅ Phoenix-Hyperon bridge  
✅ Foundation for building AGI applications  

**What to do next:**

1. **Run the examples** - Get hands-on experience
2. **Build applications** - Create something useful
3. **Join community** - Connect with other developers
4. **Contribute** - Help improve Hyperon
5. **Launch products** - Monetize your knowledge

**The bridge is built.**

**The tools are ready.**

**Now create.**

---

**© 2024-2025 Justin Conzet. All Rights Reserved.**  
**Hyperon-Phoenix Bridge. Your Path to AGI.**
