
# ARC Ledger — vNext (Forward‑Linked)

This package chains forward from the notarized pack:

- Prior pack: ARC_Immutable_Ledger_Pack.zip
- Prior SHA-256: 232484358b8fa28f1e47657906a72bf19f8ff5470e0bf9a231db64cc44e40f7f
- Place your OpenTimestamps receipt here:
  `chain/ARC_Immutable_Ledger_Pack.zip.ots`

## How to use
1) Copy ARC_Immutable_Ledger_Pack.zip into this directory (already embedded in the ZIP below).
2) Put the OTS receipt file in `chain/` (name must match the prior pack filename + `.ots`).
3) For your next run, drop raw logs here: `ARC_Run_vNext/`
   - Accepts: `csv`, `json`, `txt` (task-level predictions and outcomes).
4) When ready, we will compile:
   - `ARC_Immutable_Ledger_vNext.json` (appends new run)
   - `DECLARATION_vNext.txt` (public statement)
   - `manifest_vNext.json` (hashes)
   - and produce a new OTS-ready `to_timestamp_vNext.sha256`

This keeps your lineage unbroken and publicly verifiable.
