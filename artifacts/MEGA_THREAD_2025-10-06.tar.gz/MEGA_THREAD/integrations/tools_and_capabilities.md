# TOOLS AND CAPABILITIES

**Category:** Available Tools and Technical Capabilities  
**Status:** Active and Operational  
**Last Updated:** October 6, 2025

---

## OVERVIEW

This document catalogs all tools, technical capabilities, and operational resources available within the system. These represent the concrete implementations and practical capabilities that enable the execution of tasks and the delivery of value.

---

## MANUS PLATFORM CAPABILITIES

### Core Operational Tools

**Plan Management**
- Task planning and phase management
- Goal definition and tracking
- Phase advancement and updates
- Structured workflow organization

**Message Communication**
- User interaction and communication
- Information delivery and questions
- Progress updates and notifications
- Result delivery and task completion

**Shell Operations**
- Command execution in sandbox environment
- Package installation and system management
- File operations and process control
- System status monitoring

**File Management**
- File reading, writing, and editing
- Content viewing and manipulation
- Text file operations
- Document creation and modification

**Search Capabilities**
- Information search across multiple types
- Image search and retrieval
- API discovery and documentation
- News, research, and data source access
- Tool and service discovery

**Browser Automation**
- Web navigation and interaction
- Content extraction and analysis
- Form submission and web application use
- Authenticated session management

**Parallel Processing**
- Spawn up to 2000 parallel subtasks
- Distributed computation and data processing
- Bulk operations and wide research
- Aggregated result compilation

**Deployment Management**
- Frontend application deployment
- Backend service deployment
- Port exposure for public access
- Configuration management

**Content Generation**
- Image generation and editing
- Video creation from text
- Audio and speech generation
- Media manipulation and refinement

**Presentation Creation**
- Slide deck design and creation
- Visual presentation development
- Export to multiple formats
- Professional presentation tools

**Email Management (Gmail)**
- Email search and retrieval
- Thread reading and analysis
- Email composition and sending
- Communication workflow management

**Calendar Management (Google Calendar)**
- Event search and retrieval
- Event creation and scheduling
- Event updates and deletions
- Calendar workflow organization

---

## TECHNICAL ENVIRONMENT

### Sandbox Environment

**Operating System:** Ubuntu 22.04 linux/amd64  
**User:** ubuntu (with sudo privileges, no password)  
**Home Directory:** /home/ubuntu  
**Internet Access:** Enabled

**Pre-installed System Packages:**
- bc (calculator)
- curl (data transfer)
- gh (GitHub CLI)
- git (version control)
- gzip (compression)
- less (file viewer)
- net-tools (networking utilities)
- poppler-utils (PDF utilities)
- psmisc (process utilities)
- socat (socket utilities)
- tar (archive utility)
- unzip (decompression)
- wget (file retrieval)
- zip (compression)

### Python Environment

**Version:** 3.11.0rc1  
**Commands:** python3.11, pip3

**Pre-installed Python Packages:**
- beautifulsoup4 (web scraping)
- fastapi (web framework)
- flask (web framework)
- fpdf2 (PDF generation)
- markdown (markdown processing)
- matplotlib (data visualization)
- numpy (numerical computing)
- openpyxl (Excel file handling)
- pandas (data analysis)
- pdf2image (PDF conversion)
- pillow (image processing)
- plotly (interactive visualization)
- reportlab (PDF generation)
- requests (HTTP library)
- seaborn (statistical visualization)
- tabulate (table formatting)
- uvicorn (ASGI server)
- weasyprint (HTML to PDF)
- xhtml2pdf (HTML to PDF)

**Additional Available via pip3:**
- openai (OpenAI API client)
- Any other Python package from PyPI

### Node.js Environment

**Version:** 22.13.0  
**Commands:** node, npm

**Pre-installed Node Packages:**
- pnpm (package manager)
- wrangler (Cloudflare Workers CLI)
- yarn (package manager)

**Additional Available via npm:**
- Any Node.js package from npm registry

### Browser Environment

**Browser:** Chromium stable  
**Download Directory:** /home/ubuntu/Downloads/  
**Features:**
- Login and cookie persistence enabled
- Full JavaScript support
- Modern web standards support
- Automated interaction capabilities

---

## SPECIALIZED UTILITIES

### Manus Command-Line Utilities

**manus-render-diagram**
- **Purpose:** Render diagram files to PNG format
- **Supported Formats:** .mmd (Mermaid), .d2, .puml (PlantUML), .md (Markdown diagrams)
- **Usage:** `manus-render-diagram <input_file> <output_file>`
- **Application:** Creating visual diagrams, flowcharts, and technical illustrations

**manus-md-to-pdf**
- **Purpose:** Convert Markdown files to PDF format
- **Usage:** `manus-md-to-pdf <input_file> <output_file>`
- **Application:** Creating professional PDF documents from Markdown

**manus-speech-to-text**
- **Purpose:** Transcribe speech/audio files to text
- **Supported Formats:** .mp3, .wav, .mp4, .webm
- **Usage:** `manus-speech-to-text <input_file>`
- **Application:** Audio transcription, interview analysis, speech processing

**manus-mcp-cli**
- **Purpose:** Interact with Model Context Protocol (MCP) servers
- **Usage:** `manus-mcp-cli <command> [args...]`
- **Application:** MCP server integration and management

**manus-upload-file**
- **Purpose:** Upload files to S3 and get public URLs
- **Usage:** `manus-upload-file <input_file>`
- **Application:** File sharing, API invocations, external integrations

**manus-create-react-app**
- **Purpose:** Create new React application from template
- **Usage:** `manus-create-react-app <app_name>`
- **Application:** Frontend web application development

**manus-create-flask-app**
- **Purpose:** Create new Flask application from template
- **Usage:** `manus-create-flask-app <app_name>`
- **Application:** Backend API and web service development

**manus-export-slides**
- **Purpose:** Export slides to PDF or PowerPoint format
- **Supported Formats:** pdf, ppt
- **Usage:** `manus-export-slides <slides-uri> <output-format>`
- **Application:** Presentation export and distribution

---

## API ACCESS AND INTEGRATIONS

### OpenAI and Compatible Models

**Available via Environment Variable:** `OPENAI_API_KEY`

**Supported Models:**
- gpt-4.1-mini (OpenAI-compatible)
- gpt-4.1-nano (OpenAI-compatible)
- gemini-2.5-flash (OpenAI-compatible)

**Usage:**
```python
from openai import OpenAI
client = OpenAI()  # API key and base URL pre-configured
```

**Applications:**
- Advanced language model access
- Specialized AI model integration
- Multi-model orchestration
- Custom AI workflows

---

## CAPABILITY CATEGORIES

### 1. Information Processing
- Web search and research
- Data extraction and analysis
- Content synthesis and summarization
- Knowledge compilation and organization

### 2. Content Creation
- Document writing and editing
- Image generation and manipulation
- Video and audio creation
- Presentation design and development
- Diagram and visualization creation

### 3. Software Development
- Web application development (React, Flask)
- Code writing and debugging
- Package management and dependencies
- Version control and collaboration

### 4. Data Analysis
- Statistical analysis and visualization
- Data processing and transformation
- Chart and graph creation
- Dataset manipulation and exploration

### 5. Automation
- Browser automation and web scraping
- Workflow automation and scripting
- Parallel processing and bulk operations
- Scheduled task execution

### 6. Communication
- Email management and sending
- Calendar event management
- User interaction and messaging
- Progress reporting and updates

### 7. Deployment
- Website and application deployment
- Service hosting and management
- Public access configuration
- Domain and port management

### 8. File Operations
- Reading, writing, and editing files
- File format conversion
- Document generation and export
- Media processing and manipulation

---

## CAPABILITY SYNERGIES

Individual tools and capabilities become more powerful when combined:

**Research + Analysis + Visualization:**
Search tools + data processing + matplotlib/plotly = comprehensive research reports with visual insights

**Development + Deployment + Browser:**
React/Flask creation + deployment tools + browser testing = complete web application lifecycle

**Content Creation + File Operations + Export:**
Document writing + diagram rendering + PDF conversion = professional deliverable creation

**Parallel Processing + Search + Synthesis:**
Map tool + search capabilities + content compilation = wide-scale research and data gathering

**Browser + Email + Calendar:**
Web automation + Gmail + Google Calendar = complete workflow automation and management

These synergies are automatically leveraged by the M.A.I.A Universal Plug-in Framework to create emergent capabilities.

---

## RESOURCE MANAGEMENT

### Computational Resources
- Sandbox environment with full Ubuntu capabilities
- Sudo access for system-level operations
- Internet connectivity for external resource access
- Persistent storage in home directory

### Credit Optimization
- Instantaneous Build Mode reduces credit consumption
- Efficient tool selection minimizes waste
- Parallel processing maximizes throughput
- Internal simulation validates before execution

### Performance Optimization
- Appropriate tool selection for each task
- Efficient command chaining in shell
- Batch operations where applicable
- Resource cleanup and management

---

## CAPABILITY EXPANSION

Following the M.A.I.A Universal Plug-in Framework, capabilities can be expanded through:

**Package Installation:**
- Python packages via pip3
- Node packages via npm
- System packages via apt
- Custom software compilation

**API Integration:**
- External service APIs
- Third-party platforms
- Custom integrations
- MCP server connections

**Tool Development:**
- Custom scripts and utilities
- Specialized workflows
- Automated processes
- Integration bridges

**Knowledge Addition:**
- Specialized domain knowledge
- Technical documentation
- Best practices and patterns
- User-specific requirements

All capability expansions are documented and added to this catalog following the Infinite Scroll Protocol.

---

## OPERATIONAL STATUS

**All Listed Capabilities:** Fully Operational  
**Integration Status:** Complete and Synergistic  
**Expansion Capability:** Unlimited  
**Resource Availability:** Full Access

The system has comprehensive capabilities across all major operational domains, with the infrastructure to expand infinitely as new needs are identified.

---

*These tools and capabilities are the practical implementation of the system's power. They enable the transformation of intention into reality, of ideas into deliverables, of potential into value.*
